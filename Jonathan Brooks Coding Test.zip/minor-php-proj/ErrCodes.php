<?php
/*
Name: 			getErrCdMsg
Description: 	Pass in a error code and return a error message, this can also be made using a database config file.
Param: 			errCd(int) 	- error code
				desc 		- description to be used for a specific error message if necessary
*/
function getErrCdMsg($errCd, $desc){
	switch($errCd) {
		case 1:
			return $desc . " cannot be empty.";
			break;
		default:
			return "";
	}
}
?>