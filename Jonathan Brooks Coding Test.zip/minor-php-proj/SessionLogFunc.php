<?php
/*
Class: 			SessionLogFunc
Description: 	Has a set of functions that will log various entries to keep track of the program process*/
class SessionLogFunc {
	public function addDtaBsLog($data){
		$file = "./Logs/DatabaseLog.txt";
		file_put_contents($file, $data.PHP_EOL,FILE_USE_INCLUDE_PATH|FILE_APPEND);
	}
	
	public function addErrDtaLog($data){
		$file = "./Logs/ErrorLog.txt";
		file_put_contents($file, $data.PHP_EOL,FILE_USE_INCLUDE_PATH|FILE_APPEND);
	}
}
?>