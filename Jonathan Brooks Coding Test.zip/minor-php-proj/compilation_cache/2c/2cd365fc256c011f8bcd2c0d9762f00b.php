<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.php */
class __TwigTemplate_98c72f1bbf635aeabb56a7b5987baecd extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>
\t<style>
\t\tbody {
\t\t\tbackground-color: #05386B;
\t\t\tfont-family:Lucida Sans Unicode;
\t\t}
\t\t.button {
\t\t\tfont-family:Lucida Sans Unicode;
\t\t\tbackground-color: #4CAF50; /* Green */
\t\t\tborder: none;
\t\t\tcolor: white;
\t\t\tpadding: 15px 32px;
\t\t\ttext-align: center;
\t\t\ttext-decoration: none;
\t\t\tdisplay: inline-block;
\t\t\tfont-size: 16px;
\t\t\tmargin: 4px 2px;
\t\t\tcursor: pointer;
\t\t}

\t\t.button2 {background-color: #008CBA;} /* Blue */

\t\t.center {
\t\t\twidth: 100%;
\t\t\theight: 100%;
\t\t\t/*border: 1px solid #c3c3c3;*/
\t\t\ttext-align:center;
\t\t\tmargin-top: 50px;
\t\t}
\t</style>
</head>
<body>
<div class=\"center\">
\t<a class=\"button\" href=\"templates/CreateUser.php\">Create User</a>
\t<a class=\"button button2\" href=\"templates/CreateUserByApi.php\">Create Dummy User</a>\t
</div>
<table style=\"width:100%; background-color: white; margin-top: 50px;\" border = \"1\" id=\"userdetails\">
        <tr>
        \t";
        // line 41
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["listhead"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["list"]) {
            // line 42
            echo "            <th id=\"";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\"> ";
            echo twig_escape_filter($this->env, $context["list"], "html", null, true);
            echo " </th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['list'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "        </tr>
        \t";
        // line 45
        if ((($context["nores"] ?? null) == false)) {
            // line 46
            echo "        \t\t";
            $context["count"] = 0;
            // line 47
            echo "        \t\t";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["userinfo"] ?? null));
            foreach ($context['_seq'] as $context["type"] => $context["items"]) {
                // line 48
                echo "        \t\t\t<tr>
\t\t\t        \t";
                // line 49
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["items"]);
                foreach ($context['_seq'] as $context["key"] => $context["user"]) {
                    // line 50
                    echo "\t\t\t            <td class=\"";
                    echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                    echo "\" style=\"text-align: center;\"> 
\t\t\t            \t<input class=\"";
                    // line 51
                    echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                    echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                    echo "\" style=\"display: none;\" type=\"text\" name=\"";
                    echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                    echo "\" value=\"";
                    echo twig_escape_filter($this->env, $context["user"], "html", null, true);
                    echo "\"> 
\t\t\t            \t";
                    // line 52
                    if (($context["key"] != 6)) {
                        // line 53
                        echo "\t\t\t            \t\t<p class=\"";
                        echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                        echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                        echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $context["user"], "html", null, true);
                        echo " </p>
\t\t\t            \t";
                    } else {
                        // line 55
                        echo "\t\t\t\t\t        \t<img src=\"";
                        echo twig_escape_filter($this->env, $context["user"], "html", null, true);
                        echo "\" height=\"40\" width=\"40\t\">
\t\t\t\t\t        ";
                    }
                    // line 57
                    echo "\t\t\t            </td>
\t\t\t            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['user'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 59
                echo "\t\t\t            <td style=\"text-align: center;\"> 
\t\t\t            \t<button id=\"";
                // line 60
                echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                echo "\" type=\"button\" onclick=\"editinfo(";
                echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                echo ")\">Edit</button>
\t\t\t            \t<button id=\"";
                // line 61
                echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                echo "\" style=\"display: none;\" type=\"button\" onclick=\"submitinfo(";
                echo twig_escape_filter($this->env, twig_first($this->env, $context["items"]), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, ($context["count"] ?? null), "html", null, true);
                echo ")\">submit</button>
\t\t\t            \t<button type=\"button\" onclick=\"deluser(";
                // line 62
                echo twig_escape_filter($this->env, twig_first($this->env, $context["items"]), "html", null, true);
                echo ")\">Delete</button> 
\t\t\t            </td>
\t\t            </tr>
\t\t            ";
                // line 65
                $context["count"] = (($context["count"] ?? null) + 1);
                // line 66
                echo "\t\t        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['items'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 67
            echo "\t        ";
        } else {
            // line 68
            echo "\t        \t<td> ";
            echo twig_escape_filter($this->env, ($context["nores"] ?? null), "html", null, true);
            echo " </td>
\t        ";
        }
        // line 70
        echo "
    </table>
    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
\t<script>
\t\tfunction deluser(id){
\t\t\tconsole.log(id);
\t\t\tvar act = {\"action\": \"delete\", \"id\": id};
\t\t\tevent.preventDefault();
\t\t\t\$.ajax({
\t\t            url: \"templates/api.php\",
\t\t            method: \"POST\",
\t\t            data: act,
\t\t            success:function(act){
\t\t                window.location.href=\"\";
\t\t            }
\t\t        });
\t\t\t}

\t\tfunction editinfo(count){
\t\t\t\$(\"#\"+count).css(\"display\", \"none\");
\t\t\t\$(\"#\"+count+count).css(\"display\", \"block\");
\t\t\tfor(let i=1; i<=5; i++){
\t\t\t\t\$(\".\"+count+i).css(\"display\", \"block\");
\t\t\t\t\$(\".\"+i+count+i).css(\"display\", \"none\");
\t\t\t}
\t\t}

\t\tfunction submitinfo(data,count) {
\t\t\tvar id = data;
\t\t\tvar fname = \$(\".\"+count+\"3\").val();
\t\t\tvar lname = \$(\".\"+count+\"4\").val();
\t\t\tvar uname = \$(\".\"+count+\"1\").val();
\t\t\tvar pass = \$(\".\"+count+\"2\").val();
\t\t\tvar email = \$(\".\"+count+\"5\").val();

            if(fname == \"\") {
                alert(\"First name can not be empty\");
                return false;
            } else {
                var regex = /^[a-zA-Z\\s]+\$/;
                if(regex.test(fname) === false) {
                    alert(\"Please enter a valid first name\");
                    return false;
                } 
            }

            if(lname == \"\") {
                alert(\"Last name can not be empty\");
                return false;
            } else {
                var regex = /^[a-zA-Z\\s]+\$/;
                if(regex.test(lname) === false) {
                    alert(\"Please enter a valid last name\");
                    return false;
                } 
            }

            if(uname == \"\") {
                alert(\"Username can not be empty\");
                return false;
            } else {
                var regex = /^[a-zA-Z0-9_-]+\$/;
                if(regex.test(uname) === false) {
                    alert(\"Please enter a valid username\");
                    return false;
                }
            }

            if(email == \"\") {
                alert(\"email can not be empty\");
                return false;
            } else {
                var regex = /^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+\\.[a-zA-Z]{2,3}\$/;
                if(regex.test(email) === false) {
                    alert(\"Please enter a valid email address\");
                    return false;
                }
            }

            if(pass == \"\") {
                 alert(\"password can not be empty\");
                return false;
            } else {
                var regex = /^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{8,}\$/;
                if(regex.test(pass) === false) {
                     alert(\"Please enter a valid Password, password should contain atleat 8 alphanumeric characters\");
                     return false;
                }
            }

            const obj = {\"action\": \"edit\", \"id\": id, \"fname\":fname, \"lname\":lname, \"email\":email, \"password\":pass, \"username\":uname};
\t\t\t// console.log(obj);
\t\t\t\$.ajax({
                    url: \"templates/api.php\",
                    method: \"POST\",
                    data: obj,
                    success:function(obj){
                        // alert(data);
                        window.location.href=\"\";
                    }
                });
\t\t}
\t</script>
</body>
</html>";
    }

    public function getTemplateName()
    {
        return "index.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 70,  188 => 68,  185 => 67,  179 => 66,  177 => 65,  171 => 62,  162 => 61,  156 => 60,  153 => 59,  146 => 57,  140 => 55,  130 => 53,  128 => 52,  119 => 51,  114 => 50,  110 => 49,  107 => 48,  102 => 47,  99 => 46,  97 => 45,  94 => 44,  83 => 42,  79 => 41,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.php", "C:\\xampp\\htdocs\\Assignment_db\\templates\\index.php");
    }
}
