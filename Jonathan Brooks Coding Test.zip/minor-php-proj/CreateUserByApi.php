<?php
require './vendor/autoload.php';
require_once "DatabaseSet.php";

$client = new GuzzleHttp\Client();

$res = $client->request('GET','https://randomuser.me/api/?format=json');

$arr = json_decode($res->getBody()->getContents(), true);
// print_r($result["results"][0]);

$res = $arr["results"][0];

$newUserData = array(
	"username" => $res["login"]["username"],
	"password" =>$res["login"]["password"],
	"firstname" =>$res["name"]["first"],
	"lastname" =>$res["name"]["last"],
	"email"=>$res["email"],
	"profilephoto" =>$res["picture"]["thumbnail"]
	);
	
$database = new DatabaseSet(false);

$database->insertData($newUserData,"users");

$database->closeConnection();

?>
<!DOCTYPE HTML>
<html>

<body>

<script type="text/javascript">
// return to index.php and refresh
if ('referrer' in document) {
	window.location = document.referrer;				
} else {
	window.history.back();
}	
</script

</body>

</html>

