
<!DOCTYPE html>
<html>
	<head>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<script type="text/javascript">

	$(document).ready(function(){
		$("button").click(function(){
			// Get value from input element on the page
			var object = {
			username: $("#username").val(),
			password: $("#password").val(),
			firstname: $("#firstname").val(),
			lastname: $("#lastname").val(),
			email: $("#email").val(),
			profilephoto: ($("#files").val()!="" ? $("#files")[0].files[0]['name'] : $("#files").val())
		}
		var stringObject = JSON.stringify(object);
        // Send the input data to the server using get
        $.post("AddUser.php", {jsonData: stringObject} , function(data){
            // Display the returned data in browser
            if (data != true){
				if ('referrer' in document) {
					window.location = document.referrer;
					
				} else {
					window.history.back();
				}	
			}
			
        });
    });
});
</script>
	</head>
	<body>
		<label>Username: <input type="text" id="username"></label><br>
		<label>Password: <input type="text" id="password"></label><br>
		<label>First Name: <input type="text" id="firstname"></label><br>
		<label>Last Name: <input type="text" id="lastname"></label><br>
		<label>Email: <input type="text" id="email"></label><br>
		<label>ProfilePhoto: <input type="file" name="fileToUpload" id="files" value = " " accept="image/png, image/jpg, image/jpeg"></label><br>
		
		<button type="button">Submit</button>
		
		<div id="result"></div>
	</body>
</html>
