Database:
	1. the database is created via the 'Database.php' with the table being created by importing the 'CRTDTATBL1.sql' file and querying
	
Other Feature:
	1. CreateUser: This button will redirect you to the 'Add User' form where you can add data manually
	2. Create Dummy User: This button will redirect to you 'CreateUserByApi.php' where you'll one button. and clicking on that button will automatically
	generate user info and display it on webpage.
	 
Missing:
	1. The edit feature is missing this would be done by allowing a form to be created on the index.php page which allows the user to enter the id of the user they want to edit
	which would carry the user over to a similar page to 'CreateUser.php' if not that with some changes, while the backend would search and return the user data from the database. The user would then make the changes in the form and would then update the database using something like the following -
		update database.table
		set table.data = newdata
		where chosenUserID = table.id
	2. The delete would work the same as above allowing a form for the user to enter the id they wish to delete and search through the database confirm it exists and then using something like the following
		delete from database.table
		where chosenId = table.id
	3. CSS is missing....
