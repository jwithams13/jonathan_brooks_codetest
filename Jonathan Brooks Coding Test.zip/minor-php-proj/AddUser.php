<?php
	require_once "SessionLogFunc.php";
	require_once "DatabaseSet.php";
	require_once "ErrCodes.php";
	
	$userData = json_decode($_POST['jsonData'],true);
	
	$msgLog = new SessionLogFunc();
	
	$database = new DatabaseSet(false);
	
	# quick check if any of the manual entry data is empty. 
	if (strlen($userData['username'])<1){
		$msgLog->addErrDtaLog(getErrCdMsg(1,"Username"));
	} elseif (strlen($userData['password'])<1) {
		$msgLog->addErrDtaLog(getErrCdMsg(1,"Password"));
	} elseif (strlen($userData['firstname'])<1) {
		$msgLog->addErrDtaLog(getErrCdMsg(1,"Firstname"));
	} elseif (strlen($userData['lastname'])<1) {
		$msgLog->addErrDtaLog(getErrCdMsg(1,"Lastname"));
	} elseif (strlen($userData['email'])<1) {
		$msgLog->addErrDtaLog(getErrCdMsg(1,"Email"));
	} else {
		$database->insertData($userData,"users");
	}
	
	$database->closeConnection();
	
	$response = false;
	exit(json_encode($response));
?>