<?php
require_once "SessionLogFunc.php";
/*
	Name: 		DatabaseSet
	Info: 		This file will hold functions responsible for handling the projects database functionality.
	Author: 	#############
	Date:		28-04-2022

*/
class DatabaseSet {
	# Database Configuration Information
	private $server;
	private $username;
	private $password;
	private $databaseName; 
	private $connection;
	
	# Config Flags 
	private $lclHstCnfgFlg = false;
	
	private $DtaBsCnfgFlg = false;
	private $DtaBsTblFlg = false;
	
	private $err = false;
	
	private $msgLog;
	
	public function __construct($set){
		$this->msgLog = new SessionLogFunc();
		
		$outMsg = "Session Change log start------------------------------";
		$this->msgLog->addDtaBsLog($outMsg);
			
		//default for my localhost
		$this->setupLclHstCnfg();
		$this->setDtaBseCnfg();
		
		if ($this->DtaBsCnfgFlg == true && $this->lclHstCnfgFlg == true) {
			$outMsg = "Server Connection attempt";
			$this->msgLog->addDtaBsLog($outMsg);
			
			$this->connection = new mysqli($this->server,$this->username,$this->password);
			$this->checkConnection();
		}
		
		if ($set == true && $this->err != true){
			$this->setupDatabase();
		}
	}
	
	# SET DATABASE CHANGES
	public function closeConnection(){
		$outMsg = "Connection closed ------------------------------";
		$this->msgLog->addDtaBsLog($outMsg);
			
		$this->connection->close();
	}
	
	/*
	Name: 		insertData
	Param: 		dataAss - Associated array which should hold new data
				tblNm	- String of the table the data is going to be added into*/
	public function insertData($dataAss, $tblNm){
		$outMsg = "Attempting to add new user data";
		$this->msgLog->addDtaBsLog($outMsg);
		
		$username = $dataAss['username'];
		$password = $dataAss['password'];
		$firstname = $dataAss['firstname'];
		$lastname = $dataAss['lastname'];
		$email = $dataAss['email'];
		$profilephoto = $dataAss['profilephoto'];
		
		$qryLn = "INSERT INTO " . $this->databaseName . '.' . $tblNm . " (Username, Password, Firstname, Lastname, Email, Profilephoto)" . 
		" VALUES ('$username', '$password', '$firstname', '$lastname', '$email', '$profilephoto')";
		
		if ($this->connection->query($qryLn)) {
			$outMsg = "New new user has been added";
			$this->msgLog->addDtaBsLog($outMsg);
		}
		
	}
	
	# GET DATABASE DATA ------------------------------------------------------------
	/*
	Name: 		getAllDta
	Param:		tblNm - String of the table the data is going to be returned from
	Return: 	Associated array of the database table data
	*/
	public function getAllDta($tblNm){
		$qryLn = "SELECT * FROM " . $this->databaseName . '.' . $tblNm;
		
		$qryDta = $this->connection->query($qryLn);
		
		if ($qryDta->num_rows!=0){
			return $qryDta->fetch_all(MYSQLI_ASSOC); 
		} else {
			return null;
		}
	}
	
	# DATABASE SETUP ---------------------------------------------------------------
	private function setupDatabase(){
		$crtDtaQry = "CREATE DATABASE IF NOT EXISTS " . $this->databaseName;
		if($this->connection->query($crtDtaQry) == true) {
			$outMsg = $this->databaseName . " - Database created";
			$this->msgLog->addDtaBsLog($outMsg);
			#setup database tables
			$this->setupDtabsTbles();
		} else {
			$outMsg = "Databse creation failed: " . $this->connection->error;
			$this->msgLog->addDtaBsLog($outMsg);
			$this->connection = new mysqli($this->server,$this->username,$this->password, $this->databaseName);
			$this->checkConnection();
		}
	}
	
	private function setupDtabsTbles(){
		$fileName = "CRTDTATBL1.sql";
		if ($this->DtaBsTblFlg == true) {
			$tmpQry = $this->getSqlQryFl($fileName);
			if($this->connection->query($tmpQry)) {
				$outMsg= $fileName . " - Table successfully created in Database";
				$this->msgLog->addDtaBsLog($outMsg);
			} else {
				$outMsg= "Error creating table: " . $this->connection->error;
				$this->msgLog->addDtaBsLog($outMsg);
				$outMsg = $fileName . " - Table not successfully created in Database";
				$this->msgLog->addDtaBsLog($outMsg);
			}
		}
	}
	
	# IMPORT EXTERNAL FILE ------------------------------------------------------------
	/*
	getSqlQryFl - Get a specified SQL query from an external .SQL file.
		param: $fileName - String passed through
		return: $templine - String returned - Query gotten from file returned
		Source ref: https://dev.to/erhankilic/how-to-import-sql-file-with-php--1jbc
	*/
	private function getSqlQryFl($fileName){
		$outMsg= $fileName . " - Attempt import SQL";
		$this->msgLog->addDtaBsLog($outMsg);
		// Temporary variable, used to store current query
		$templine = '';
		// Read in entire file
		$lines = file($fileName);
		// Loop through each line
		foreach ($lines as $line) {
			// Skip it if it's a comment
			if (substr($line, 0, 2) == '--' || $line == '')
				continue;

			// Add this line to the current segment
			$templine .= $line;
			// If it has a semicolon at the end, it's the end of the query
			if (substr(trim($line), -1, 1) == ';') {
				break;
			}
		}
		$outMsg= $fileName . " - SQL Query imported successfully";
		$this->msgLog->addDtaBsLog($outMsg);
		return $templine;
	}
	
	# CONFIG SECTION ------------------------------------------------------------
	private function setupLclHstCnfg(){
		$this->server  = "127.0.0.1";
		$this->username = "root";
		$this->password = "";
		$this->lclHstCnfgFlg = true;
		
		$outMsg = "Config  - Local Host Config Set";
		$this->msgLog->addDtaBsLog($outMsg);
	}
	
	private function setdtaBseCnfg(){
		$this->queryFileName = "createTable.sql";
		$this->databaseName = "test";
		$this->DtaBsCnfgFlg = true;
		$this->DtaBsTblFlg = true;
		
		$outMsg = "Config  - Database Config Set";
		$this->msgLog->addDtaBsLog($outMsg);
	}
	
	# Error Check ------------------------------------------------------------
	
	private function checkConnection(){
		if ($this->connection->connect_error == true) {
			$outMsg = "Server Connection not made";
			$this->msgLog->addDtaBsLog($outMsg);
			$err = true;
			die("Connection failed: " . $this->connection->connect_error);
		} else {
			$outMsg = "Server Connection Successfully made";
			$this->msgLog->addDtaBsLog($outMsg);
		}
	}
}
?>
