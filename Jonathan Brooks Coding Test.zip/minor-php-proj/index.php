<?php
	require_once "DatabaseSet.php";
	
	$database = new DatabaseSet(true);
	
	$tableData = $database->getAllDta("users");
	
	$columns = array();
	
	if (!empty($tableData)){
		$columns = array_keys($tableData[0]);
	} else {
		echo "There are no users, Please manually add some or use the API.<br>";
	}
	# Set column names
	if (!empty($columns)){
		$table = '<table border="1" cellspacing="5" cellpadding="1"> 
		<tr>'; 
		for ($x =0 ;$x<count($columns);$x++){
			$table .= "<td> <font face="."Arial".">" . "<b>".$columns[$x]."</b>" ."</font> </td>";
			}  	  
		  $table.='</tr>';
		  echo $table;
		  }
		  
	# Add table data
	if (!empty($tableData)){
		$table = '<tr>'; 
		foreach ($tableData as $row){
			for ($y =0 ;$y<count($columns);$y++){ 
			$table .= "<td> <font face="."Arial".">" . $row[$columns[$y]]. "</font> </td>";
			}  	  
		  $table.='</tr>';
		  }
		  echo $table;
	}
	
	$database->closeConnection();
?>

<!DOCTYPE html>
<html>
	<head></head>
	<form action="CreateUser.php" method="get">
		<input type="submit" value="Create User">
	</form>
	<form action="CreateUserByApi.php" method="get">
		<input type="submit" value="Create Dummy User">
	</form>
	<body></body>
</html>