
CREATE TABLE IF NOT EXISTS test.users (
	Id int(3) not null AUTO_INCREMENT,
	Username varchar(50),
	Password varchar(100),
	Firstname varchar(50),
	Lastname varchar(50),
	Email varchar(50),
	Profilephoto varchar(100),
	primary key(Id)
	);
	